package servlet;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLDecoder;
import java.text.SimpleDateFormat;
import java.time.DayOfWeek;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.List;
import java.util.TimeZone;

import javax.mail.MessagingException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.util.BaseServlet;
import com.util.DateUtil;
import com.util.GetJspInfo;
import com.util.Page;
import com.util.PublicCmd;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * 签到管理
 * 
 * @author wzy
 */
@SuppressWarnings({ "serial", "rawtypes", "unused" })
public class QdglServlet extends BaseServlet {
	// 操作标志
	private String flag = "";

	// 查询签到名称信息
	public void find(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// 当前登录签到名称信息
		Hashtable hasuser = (Hashtable) request.getSession().getAttribute("login_user");
		flag = request.getParameter("flag");
		// 获取页面查询条件
		Hashtable ht = GetJspInfo.getRequestDataWithPrefixUnicode("find_qdgl_", request);
		// 获取排序条件
		String pxtj = "";
		String cxtj = "";
		if (ht != null) {
			String rqq = ht.get("RQQ") == null ? "" : (String) ht.get("RQQ");
			if (!"".equals(rqq)) {
				cxtj = cxtj + "&rqq=" + rqq;
				pxtj = pxtj + " and qdrq >= '" + rqq + "'";
			}

			String rqz = ht.get("RQZ") == null ? "" : (String) ht.get("RQZ");
			if (!"".equals(rqz)) {
				cxtj = cxtj + "&rqz=" + rqz;
				pxtj = pxtj + " and qdrq <= '" + rqz + "'";
			}

			request.setAttribute("rqq", rqq);
			request.setAttribute("rqz", rqz);
		} else {
			String rqq = request.getParameter("rqq") == null ? "" : request.getParameter("rqq");
			if (!"".equals(rqq)) {
				cxtj = cxtj + "&rqz=" + rqq;
				pxtj = pxtj + " and qdrq >='" + rqq + "'";
			}

			String rqz = request.getParameter("rqz") == null ? "" : request.getParameter("rqz");
			if (!"".equals(rqz)) {
				cxtj = cxtj + "&rqz=" + rqz;
				pxtj = pxtj + " and qdrq <='" + rqz + "'";
			}

			request.setAttribute("rqq", rqq);
			request.setAttribute("rqz", rqz);
		}

		String indexKey = "id";// 排序关键
		String sort = " asc ";
		// 查询信息
		String sql = "select qdrq,qdsj,case when xbsj is null then '' else xbsj end as xbsj from qdb where qdr= "
				+ hasuser.get("ID") + pxtj;
		/* 分页 */
		String sql0 = "select count(1) from (" + sql + ") cona";
		int size = 0;
		if ("-2".equals(PublicCmd.find_returnOne(sql0))) {
			size = 0;
		} else {
			size = Integer.parseInt(PublicCmd.find_returnOne(sql0));
		}
		long curPage = 0l;
		if (null == request.getParameter("curPage") || "".equals(request.getParameter("curPage"))) {
			curPage = 1l;
		} else {
			curPage = Long.parseLong(request.getParameter("curPage"));
		}
		int pageSize = 8;

		String types = "mysql";
		sql = Page.getSql(sql, curPage, pageSize, indexKey, sort, types);
		String target = request.getContextPath() + "/servlet/QdglServlet?action=find&flag=" + flag + cxtj + "&";
		String linkStr = Page.getPagestr(size, pageSize, curPage, target);
		request.setAttribute("linkStr", linkStr);
		/* 分页 */
		ArrayList qdgl_arr = PublicCmd.find_allObject(sql);
		request.setAttribute("qdgl_arr", qdgl_arr);

		request.getRequestDispatcher("/qdgl.jsp").forward(request, response);
	}

	public void welcome(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// 当前用户
		Hashtable hasuser = (Hashtable) request.getSession().getAttribute("login_user");
		// 查询当前用户是否请假
		String qjcountsql = "select count(1) from qjb where shbz='T' and qjrq=SUBSTR(now() FROM 1 FOR 10) and qjr="
				+ hasuser.get("ID");
		String qjcount = PublicCmd.find_returnOne(qjcountsql);
		request.setAttribute("qjcount", qjcount);
		// 查询当前用户是否签到
		String countsql = "select count(1) from qdb where qdrq=SUBSTR(now() FROM 1 FOR 10) and qdr="
				+ hasuser.get("ID");
		String count = PublicCmd.find_returnOne(countsql);
		request.setAttribute("count", count);
		//判断是否是周末
		boolean iszm=false;
		LocalDateTime now = LocalDateTime.now();
		DayOfWeek dayOfWeek = now.getDayOfWeek();
		if(dayOfWeek == DayOfWeek.SATURDAY || dayOfWeek == DayOfWeek.SUNDAY){
			iszm=true;
		}else {
			iszm=false;
		}
		request.setAttribute("iszm", iszm);
		// 查询下班信息
		String dksql = "select xbsj from qdb where qdrq=SUBSTR(now() FROM 1 FOR 10) and qdr=" + hasuser.get("ID");
		String xbsj = PublicCmd.find_returnOne(dksql);
		request.setAttribute("xbsj", xbsj);
		request.getRequestDispatcher("/welcome.jsp").forward(request, response);
	}

	// 签到
	public void qd(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// 当前用户
		Hashtable hasuser = (Hashtable) request.getSession().getAttribute("login_user");
		// 查询当前用户是否签到
		String countsql = "select count(1) from qdb where qdrq=SUBSTR(now() FROM 1 FOR 10) and qdr="
				+ hasuser.get("ID");
		String count = PublicCmd.find_returnOne(countsql);
		if ("0".equals(count)) {
			String qdsql = "insert into qdb (qdrq,qdsj,qdr) values(SUBSTR(now() FROM 1 FOR 10),now(),"
					+ hasuser.get("ID") + ")";
			if (PublicCmd.update(qdsql)) {
				response.getWriter().print("<script type='text/javascript'>alert('签到成功');" + "location='"
						+ request.getContextPath() + "/welcome.jsp?loadbz=load'</script>");
			} else {
				response.getWriter()
						.print("<script type='text/javascript'>alert('签到失败，请刷新后重试');window.history.go(-1);</script>");
			}
		} else {
			response.getWriter().print(
					"<script type='text/javascript'>alert('签到失败，今日已经签到，请刷新后重试');window.history.go(-1);</script>");
		}
	}

	// 下班打开
	public void dk(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// 当前用户
		Hashtable hasuser = (Hashtable) request.getSession().getAttribute("login_user");
		// 查询当前用户是否签到
		String countsql = "select count(1) from qdb where qdrq=SUBSTR(now() FROM 1 FOR 10) and qdr=" + hasuser.get("ID")
				+ " and xbsj is not null";
		String count = PublicCmd.find_returnOne(countsql);
		if ("0".equals(count)) {
			String qdsql = "update qdb set xbsj=now() where qdrq=SUBSTR(now() FROM 1 FOR 10) and qdr="
					+ hasuser.get("ID") + " and xbsj is null";
			if (PublicCmd.update(qdsql)) {
				response.getWriter().print("<script type='text/javascript'>alert('打卡成功');" + "location='"
						+ request.getContextPath() + "/welcome.jsp?loadbz=load'</script>");
			} else {
				response.getWriter()
						.print("<script type='text/javascript'>alert('打卡失败，请刷新后重试');window.history.go(-1);</script>");
			}
		} else {
			response.getWriter().print(
					"<script type='text/javascript'>alert('打卡失败，今日已经打卡，请刷新后重试');window.history.go(-1);</script>");
		}
	}
}
