package servlet;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;

import src.util.SysInfo;


/**
 * 工程启动时加载，application中的公用信息
 * 
 * @author XZY 2011-08-16
 */
public class OnloadServlet extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private ServletContext sct;

	public void init() throws ServletException {
		sct = this.getServletContext();
		SysInfo sysInfo = new SysInfo(sct);// 初始化公用信息
	}
}
