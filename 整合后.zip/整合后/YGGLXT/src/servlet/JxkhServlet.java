package servlet;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLDecoder;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.List;
import java.util.TimeZone;

import javax.mail.MessagingException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.util.BaseServlet;
import com.util.DateUtil;
import com.util.GetJspInfo;
import com.util.Page;
import com.util.PublicCmd;

import src.util.PublicUtil;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * 绩效考核
 * 
 * @author wzy
 */
@SuppressWarnings({ "serial", "rawtypes", "unused" })
public class JxkhServlet extends BaseServlet {
	// 操作标志
	private String flag = "";

	// 绩效考核
	public void jxkh(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// 当前登录请假名称信息
		Hashtable hasuser = (Hashtable) request.getSession().getAttribute("login_user");
		flag = request.getParameter("flag");
		// 获取页面查询条件
		Hashtable ht = GetJspInfo.getRequestDataWithPrefixUnicode("jxkh_", request);
		// 获取排序条件
		int zts = 0;// 总天数
		String qdtj = "";// 签到条件
		String qjtj = "";// 请假条件
		String cxtj = "";
		if (ht != null) {
			String rqq = ht.get("RQQ") == null ? "" : (String) ht.get("RQQ");
			if (!"".equals(rqq)) {
				cxtj = cxtj + "&rqq=" + rqq;
				qjtj = qjtj + " and qjrq >= '" + rqq + "'";
				qdtj = qdtj + " and qdrq >= '" + rqq + "'";
			}

			String rqz = ht.get("RQZ") == null ? "" : (String) ht.get("RQZ");
			if (!"".equals(rqz)) {
				cxtj = cxtj + "&rqz=" + rqz;
				qjtj = qjtj + " and qjrq <= '" + rqz + "'";
				qdtj = qdtj + " and qdrq <= '" + rqz + "'";
			}
			zts = getrqdts(rqq, rqz, "yyyy-MM-dd");

			request.setAttribute("rqq", rqq);
			request.setAttribute("rqz", rqz);
		} else {
			String rqq = request.getParameter("rqq") == null ? "" : request.getParameter("rqq");
			if (!"".equals(rqq)) {
				cxtj = cxtj + "&rqq=" + rqq;
				qjtj = qjtj + " and qjrq >= '" + rqq + "'";
				qdtj = qdtj + " and qdrq >= '" + rqq + "'";
			}

			String rqz = request.getParameter("rqz") == null ? "" : request.getParameter("rqz");
			if (!"".equals(rqz)) {
				cxtj = cxtj + "&rqz=" + rqz;
				qjtj = qjtj + " and qjrq <= '" + rqz + "'";
				qdtj = qdtj + " and qdrq <= '" + rqz + "'";
			}
			zts = getrqdts(rqq, rqz, "yyyy-MM-dd");
			request.setAttribute("rqq", rqq);
			request.setAttribute("rqz", rqz);
		}
		System.out.println(zts);
		String indexKey = "id";// 排序关键
		String sort = " asc ";
		// 查询信息
		String sql = "select t.id,t.bmmc,t.rs,t.ts,t.zts,t.qdts,case when t.zts=0 then '' else CONCAT(round(t.qdts/t.zts*100,2),'%') end as qdl,t.qjts,"
				+ "case when t.zts=0 then '' else CONCAT(round(t.qjts/t.zts*100,2) ,'%')end as qjl from ("
				+ "select t.id,t.bmmc,f.rs,f.ts,case when f.zts is null then 0 else f.zts  end as zts ,"
				+ "case when f.qdts is null then 0 else f.qdts  end as qdts,"
				+ "case when f.qjts is null then 0 else f.qjts  end as qjts  from bmb t left join ("
				+ "select bmid,count(1) rs,max(zts) as ts, sum(zts)as zts,sum(qdts) as qdts,sum(qjts) as qjts from ("
				+ "select id,xm,xb,bmid," + zts + " as zts,case when b.qdts is null then 0 else b.qdts end as qdts,"
				+ "case when c.qjts is null then 0 else c.qjts end as qjts from yhb a "
				+ "left join (select qdr,count(1)as qdts from qdb where 1=1 " + qdtj + " group by qdr)b on a.id=b.qdr "
				+ "left join (select qjr,count(1) as qjts from qjb where shbz='T' " + qjtj + " group by qjr)c "
				+ "on a.id=c.qjr where js=3)a group by a.bmid) f on t.id=f.bmid )t";

		/* 分页 */
		String sql0 = "select count(1) from (" + sql + ") cona";
		int size = 0;
		if ("-2".equals(PublicCmd.find_returnOne(sql0))) {
			size = 0;
		} else {
			size = Integer.parseInt(PublicCmd.find_returnOne(sql0));
		}
		long curPage = 0l;
		if (null == request.getParameter("curPage") || "".equals(request.getParameter("curPage"))) {
			curPage = 1l;
		} else {
			curPage = Long.parseLong(request.getParameter("curPage"));
		}
		int pageSize = 8;

		String types = "mysql";
		sql = Page.getSql(sql, curPage, pageSize, indexKey, sort, types);
		String target = request.getContextPath() + "/servlet/QjglServlet?action=jxkh&flag=" + flag + cxtj + "&";
		String linkStr = Page.getPagestr(size, pageSize, curPage, target);
		request.setAttribute("linkStr", linkStr);
		/* 分页 */
		ArrayList jxkh_arr = PublicCmd.find_allObject(sql);
		request.setAttribute("jxkh_arr", jxkh_arr);

		request.getRequestDispatcher("/jxkh.jsp").forward(request, response);
	}

	// 获取日期天数间隔
	public static final int getrqdts(String startrq, String endrq, String type) {
		String rtype = "EEEE";
		int ts = 0;
		SimpleDateFormat df = new SimpleDateFormat(type);// 获取星期几的格式
		df.setTimeZone(TimeZone.getTimeZone("Asia/Shanghai"));
		SimpleDateFormat rdf = new SimpleDateFormat(rtype);// 获取星期几的格式
		rdf.setTimeZone(TimeZone.getTimeZone("Asia/Shanghai"));
		Long zytimes = 0l;
		Date sdate = new Date();
		try {
			sdate = df.parse(startrq);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		Date edate = new Date();
		try {
			edate = df.parse(endrq);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		zytimes = sdate.getTime();
		Long qttimes = 0l;
		int i = 0;
		do {
			if (qttimes == 0l) {
				qttimes = zytimes;
			} else {
				zytimes = sdate.getTime();
				qttimes = zytimes + 24 * 60 * 60 * 1000;
			}
			sdate.setTime(qttimes);
			if (!"星期六".equals(rdf.format(sdate)) && !"星期日".equals(rdf.format(sdate))) {
				ts++;
			}
			i++;
		} while (!sdate.equals(edate));
		return (ts);
	}

}
