package servlet;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLDecoder;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.List;
import java.util.TimeZone;

import javax.mail.MessagingException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.util.BaseServlet;
import com.util.DateUtil;
import com.util.GetJspInfo;
import com.util.Page;
import com.util.PublicCmd;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * 部门管理
 * 
 * @author wzy
 */
@SuppressWarnings({ "serial", "rawtypes", "unused" })
public class BmglServlet extends BaseServlet {
	// 操作标志
	private String flag = "";

	// 查询部门名称信息
	public void find(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// 当前登录部门名称信息
		Hashtable hasuser = (Hashtable) request.getSession().getAttribute("login_user");
		flag = request.getParameter("flag");
		// 获取页面查询条件
		Hashtable ht = GetJspInfo.getRequestDataWithPrefixUnicode("find_bmgl_", request);
		// 获取排序条件
		String pxtj = "";
		String cxtj = "";
		if (ht != null) {
			String bmmc = ht.get("BMMC") == null ? "" : (String) ht.get("BMMC");
			if (!"".equals(bmmc)) {
				cxtj = cxtj + "&bmmc=" + bmmc;
				pxtj = pxtj + " and bmmc like '%" + bmmc + "%'";
			}
		} else {
			String bmmc = request.getParameter("bmmc") == null ? "" : request.getParameter("bmmc");
			if (!"".equals(bmmc)) {
				cxtj = cxtj + "&bmmc=" + bmmc;
				pxtj = pxtj + " and bmmc like '%" + bmmc + "%'";
			}
		}

		String indexKey = "id";// 排序关键
		String sort = " asc ";
		// 查询信息
		String sql = "select t.id,t.bmmc from bmb t where 1=1 " + pxtj;

		/* 分页 */
		String sql0 = "select count(1) from (" + sql + ") cona";
		int size = 0;
		if ("-2".equals(PublicCmd.find_returnOne(sql0))) {
			size = 0;
		} else {
			size = Integer.parseInt(PublicCmd.find_returnOne(sql0));
		}
		long curPage = 0l;
		if (null == request.getParameter("curPage") || "".equals(request.getParameter("curPage"))) {
			curPage = 1l;
		} else {
			curPage = Long.parseLong(request.getParameter("curPage"));
		}
		int pageSize = 8;

		String types = "mysql";
		sql = Page.getSql(sql, curPage, pageSize, indexKey, sort, types);
		String target = request.getContextPath() + "/servlet/BmglServlet?action=find&flag=" + flag + cxtj + "&";
		String linkStr = Page.getPagestr(size, pageSize, curPage, target);
		request.setAttribute("linkStr", linkStr);
		/* 分页 */
		ArrayList bmgl_arr = PublicCmd.find_allObject(sql);
		request.setAttribute("bmgl_arr", bmgl_arr);

		request.getRequestDispatcher("/bmgl.jsp").forward(request, response);
	}

	// 信息初始化跳转
	public void intxxedit(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// 当前登录部门名称信息
		Hashtable hasuser = (Hashtable) request.getSession().getAttribute("login_user");
		flag = request.getParameter("flag");
		request.setAttribute("flag", flag);
		// String id = (String) request.getAttribute("ID");
		String id = request.getParameter("id") == null ? "" : request.getParameter("id");
		if (!"".equalsIgnoreCase(id)) {
			String sql = "select t.* from bmb t where  t.id=" + id;
			Hashtable ht = PublicCmd.find_OneObject(sql);
			request.setAttribute("rbht", ht);
		} else {
		}
		request.getRequestDispatcher("/bmedit.jsp").forward(request, response);
	}

	// 保存部门名称信息
	public void savebmxx(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// 获取页面信息通过方法转成hashtable
		String id = request.getParameter("id");
		Hashtable ht = GetJspInfo.getRequestDataWithPrefixUnicode("up_bmxx_", request);
		if ("0".equals(id)) {
			String countsql = "select count(1) from bmb t where t.bmmc='" + ht.get("BMMC") + "' ";
			String co = PublicCmd.find_returnOne(countsql);
			if ("0".equals(co))// 部门名称不重复，可以注册
			{
				if (PublicCmd.insert_returnflag(ht, "bmb")) {
					response.setContentType("text/html;charset=utf-8");
					response.getWriter().print("<script type='text/javascript'>alert('保存成功');" + "location='"
							+ request.getContextPath() + "/bmgl.jsp?loadbz=load'</script>");
				} else {

					response.setContentType("text/html;charset=utf-8");
					response.getWriter()
							.print("<script type='text/javascript'>alert('保存失败，请重试');window.history.go(-1);</script>");
				}
			} else {
				response.setContentType("text/html;charset=utf-8");
				response.getWriter().print(
						"<script type='text/javascript'>alert('保存，部门名称已存在，请修改后重试');window.history.go(-1);</script>");
			}
		} else {
			String sql = "update bmb set bmmc='" + ht.get("BMMC") + "' ";
			sql = sql + " where id=" + id;
			String message = "";
			if (PublicCmd.update(sql)) {
				message = "修改成功！";
				String usersql = "select * from bmb where id=" + id;// 查询sql语句
				Hashtable returuser = PublicCmd.find_OneObject(usersql);// 根据部门名称查询条数据
				response.setContentType("text/html;charset=utf-8");
				response.getWriter().print("<script type='text/javascript'>alert('" + message + "');" + "location='"
						+ request.getContextPath() + "/bmgl.jsp?loadbz=load'</script>");
			} else {
				response.setContentType("text/html;charset=utf-8");
				response.getWriter()
						.print("<script type='text/javascript'>alert('修改失败，请重试');window.history.go(-1);</script>");
			}
		}
	}

	public void delxx(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// 获取页面信息通过方法转成hashtable
		String id = request.getParameter("id");
		String updatesql = "";
		String sql = "delete from  bmb ";
		sql = sql + " where id=" + id;
		String message = "";
		if (PublicCmd.update(sql)) {
			message = "删除成功！";
			String usersql = "select * from bmb where id=" + id;// 查询sql语句
			Hashtable returuser = PublicCmd.find_OneObject(usersql);// 根据部门名称查询条数据
			response.setContentType("text/html;charset=utf-8");
			response.getWriter().print("<script type='text/javascript'>alert('" + message + "');" + "location='"
					+ request.getContextPath() + "/bmgl.jsp?loadbz=load'</script>");
		} else {
			response.setContentType("text/html;charset=utf-8");
			response.getWriter()
					.print("<script type='text/javascript'>alert('删除失败，请重试');window.history.go(-1);</script>");
		}

	}

}
