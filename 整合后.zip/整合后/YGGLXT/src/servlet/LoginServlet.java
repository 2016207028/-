package servlet;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Hashtable;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import com.util.BaseServlet;
import com.util.DateUtil;
import com.util.GetJspInfo;
import com.util.PublicCmd;

import src.util.PublicUtil;

@SuppressWarnings({ "rawtypes", "serial" })
public class LoginServlet extends BaseServlet {

	// 登录
	public void login(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// 获取页面信息通过方法转成hashtable
		Hashtable ht = GetJspInfo.getRequestDataWithPrefixUnicode("login_", request);
		String sql = "select t.*,a.bmmc as bm,b.js as jsmc from yhb t left join bmb a on t.bmid=a.id left join jsb b on b.id=t.js where 1=1 ";// 查询sql语句
		String name = (String) ht.get("YHM");// 用户名
		// 特殊字符简单处理
		name = name.replace("'", "''");
		name = name.replace(" ", "");

		String pwdInput = (String) ht.get("MM");// 密码
		sql = sql + " and yhm='" + name + "'";
		Hashtable returuser = PublicCmd.find_OneObject(sql);// 根据用户名查询条数据

		if (null == returuser || returuser.isEmpty()) {
			// 查询有无用户
			String message = "用户不存在，请重新输入！";
			request.setAttribute("message", message);
			response.setContentType("text/html;charset=utf-8");
			response.getWriter()
					.print("<script type='text/javascript'>alert('" + message + "');window.history.go(-1);</script>");
		} else {
			// 存在用户，检测密码是否正确
			if (pwdInput.equals((String) returuser.get("MM"))) {
				request.getSession().setAttribute("login_user", returuser);
				response.sendRedirect(request.getContextPath() + "/frame.jsp");
			} else {
				// 密码错误，跳转重新登录
				String message = "密码输入错误，请重新输入！";
				response.setContentType("text/html;charset=utf-8");
				response.getWriter().print(
						"<script type='text/javascript'>alert('" + message + "');window.history.go(-1);</script>");
			}
		}

	}

	// 保存个人信息
	public void savegrxx(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// 文件上传
		String id = "";
		String yhm = "";
		String xpwd = "";
		String xm = "";
		// 获得磁盘文件条目工厂
		DiskFileItemFactory factory = new DiskFileItemFactory();
		// 获取文件需要上传到的路径
		String path = request.getRealPath("/file");
		// 如果没以下两行设置的话，上传大的 文件 会占用 很多内存，
		// 设置暂时存放的 存储室 , 这个存储室，可以和 最终存储文件 的目录不同
		/**
		 * 原理 它是先存到 暂时存储室，然后在真正写到 对应目录的硬盘上， 按理来说 当上传一个文件时，其实是上传了两份，第一个是以 .tem
		 * 格式的 然后再将其真正写到 对应目录的硬盘上
		 */
		factory.setRepository(new File(path));
		// 设置 缓存的大小，当上传文件的容量超过该缓存时，直接放到 暂时存储室
		factory.setSizeThreshold(1024 * 1024);
		// 高水平的API文件上传处理
		ServletFileUpload upload = new ServletFileUpload(factory);
		try {
			// 可以上传多个文件
			List<FileItem> list = (List<FileItem>) upload.parseRequest(request);
			for (FileItem item : list) {
				// 获取表单的属性名字
				String name = item.getFieldName();
				// 如果获取的 表单信息是普通的 文本 信息
				if (item.isFormField()) {
					// 获取用户具体输入的字符串 ，名字起得挺好，因为表单提交过来的是 字符串类型的
					if (name.equals("id")) {
						id = PublicUtil.toUnicode(item.getString());
					} else if (name.equals("yhm")) {
						yhm = PublicUtil.toUnicode(item.getString());
					} else if (name.equals("xpwd")) {
						xpwd = PublicUtil.toUnicode(item.getString());
					} else if (name.equals("xm")) {
						xm = PublicUtil.toUnicode(item.getString());
					}
					// 对传入的非 简单的字符串进行处理 ，比如说二进制的 图片这些
					else {
						/**
						 * 以下三步，主要获取 上传文件的名字
						 */
						// 图片目录
						String fileml = "xxtp";
						// 获取路径名
						String value = item.getName();
						if (!"".equals(value) && value != null) {
							// 索引到最后一个反斜杠
							int start = value.lastIndexOf("\\");
							// 截取 上传文件的 字符串名字，加1是 去掉反斜杠，
							String filename = value.substring(start + 1);// 获取文件名称
							request.setAttribute(name, filename);
							String typename = filename.substring(filename.lastIndexOf(".") + 1, filename.length());// 获取后缀名
							String nowtime = PublicUtil.getNowTime();// 根据当前时间生成文件名称
							String date = DateUtil.getDate("yyyyMMdd");// 根据日期生成目录
							String allpath = path + "/" + fileml + "/" + date;
							PublicUtil.checkfilepath(allpath);
							// 判断目录是否存在
							filename = nowtime + "." + typename;// 生成新的文件名称
							// 真正写到磁盘上
							// 它抛出的异常 用exception 捕捉
							// item.write( new File(path,filename) );//第三方提供的
							// 手动写的
							OutputStream out = new FileOutputStream(new File(allpath, filename));
							InputStream in = item.getInputStream();
							int length = 0;
							byte[] buf = new byte[1024];
							// in.read(buf) 每次读到的数据存放在 buf 数组中
							while ((length = in.read(buf)) != -1) {
								// 在 buf 数组中 取出数据 写到 （输出流）磁盘上
								out.write(buf, 0, length);
							}
							in.close();
							out.close();
						}
					}
				}
			}

		} catch (FileUploadException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		String sql = "update yhb set yhm='" + yhm + "',xm='" + xm + "' ";

		if (!"".equals(xpwd) && xpwd != null) {
			sql = sql + ",pwd='" + xpwd + "' ";
		}
		sql = sql + " where id=" + id;
		String message = "";
		if (PublicCmd.update(sql)) {
			message = "修改成功！";
			response.setContentType("text/html;charset=utf-8");
			String usersql = "select t.*,a.bmmc as bm,b.js as jsmc from yhb t left join bmb a on t.bmid=a.id left join jsb b on b.id=t.js where t.id="
					+ id;// 查询sql语句
			Hashtable returuser = PublicCmd.find_OneObject(usersql);// 根据用户名查询条数据
			request.setAttribute("message", message);
			request.getSession().setAttribute("login_user", returuser);
			response.getWriter().print("<script type='text/javascript'>alert('" + message + "');" + "location='"
					+ request.getContextPath() + "/grxx.jsp'</script>");
		} else {
			response.setContentType("text/html;charset=utf-8");
			response.getWriter()
					.print("<script type='text/javascript'>alert('修改失败，请重试');window.history.go(-1);</script>");
		}
	}

	public void exit(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String flag = request.getParameter("flag");// flag
		request.getSession().removeAttribute("login_user");
		if ("ht".equals(flag)) {
			response.sendRedirect(request.getContextPath() + "/index.jsp");
		} else {
			response.setContentType("text/html;charset=utf-8");
			response.getWriter().print("<script type='text/javascript'>alert('注销成功');" + "location='"
					+ request.getContextPath() + "/LoginServlet?action=Index'</script>");
		}
	}
}
