package src.util;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Random;
import java.util.TimeZone;

public class PublicUtil {

	public static String OCRPath;

	// 构造函数
	PublicUtil() {
		// 读取配置文件，加在默认信息

	}

	public static final String getNowYear() {
		Calendar currentdate = Calendar.getInstance();
		currentdate.setTimeZone(TimeZone.getTimeZone("Asia/Shanghai"));
		String nowyear = Integer.toString(currentdate.get(Calendar.YEAR));
		return nowyear;
	}

	public static final String getNowMonth() {
		Calendar currentdate = Calendar.getInstance();
		currentdate.setTimeZone(TimeZone.getTimeZone("Asia/Shanghai"));
		String nowmonth = Integer.toString(currentdate.get(Calendar.MONTH) + 1);
		if (nowmonth.length() == 1) {
			nowmonth = "0" + nowmonth;
		}
		return nowmonth;
	}

	/**
	 * <br>
	 * 方法说明：返回当前时间 <br>
	 * 输入参数： <br>
	 * 返回类型：String：yyyy+随机两位数+MMddkkmm 格式的当前日期
	 */
	public static final String getNowTime() {
		Calendar currentdate = Calendar.getInstance();
		currentdate.setTimeZone(TimeZone.getTimeZone("Asia/Shanghai"));
		Random random = new Random();
		String strDate = Integer.toString(currentdate.get(Calendar.YEAR)) + random.nextInt(10000);
		if (currentdate.get(Calendar.MONTH) + 1 < 10)
			strDate = strDate + "0";
		strDate = strDate + (currentdate.get(Calendar.MONTH) + 1);
		if (currentdate.get(Calendar.DATE) < 10)
			strDate = strDate + "0";
		strDate = strDate + currentdate.get(Calendar.DATE);
		if (currentdate.get(Calendar.HOUR_OF_DAY) < 10)
			strDate = strDate + "0";
		strDate = strDate + currentdate.get(Calendar.HOUR_OF_DAY);
		if (currentdate.get(Calendar.MINUTE) < 10)
			strDate = strDate + "0";
		strDate = strDate + currentdate.get(Calendar.MINUTE);
		return (strDate);
	}

	/* 中文处理 */
	public static final String toUnicode(String str) {
		try {
			return new String(str.getBytes("8859_1"), "UTF-8");
		} catch (Exception e) {
			return str;
		}
	}

	/**
	 * 检查文件是否存在，若不存在，则创建目录
	 */
	public static boolean checkfilepath(String filepath) {
		boolean flag = false;
		boolean oexists = (new File(filepath)).isDirectory();
		if (!oexists) {
			try {
				(new File(filepath)).mkdirs();
				flag = true;
			} catch (Exception e) {
				flag = false;
			}
		} else {
			flag = true;
		}
		return flag;
	}

	// 获取当前时间
	public static final String getDate(String type) {
		Date date = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat(type);// 转换格式
		sdf.setTimeZone(TimeZone.getTimeZone("Asia/Shanghai"));
		return sdf.format(date);
	}

	public static void main(String[] args) {
		
	}

}
