


//bd大小

//$("#bd").height($(window).height());

